function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Iu8ZOoXtpB":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

